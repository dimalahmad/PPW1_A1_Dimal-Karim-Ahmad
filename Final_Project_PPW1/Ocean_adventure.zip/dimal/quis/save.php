<?php
include_once "../functions/functions.php";
saveScore($_GET['id'],$_GET['score'],$_COOKIE["user_id"]);
header("Location: ../ocean/");
