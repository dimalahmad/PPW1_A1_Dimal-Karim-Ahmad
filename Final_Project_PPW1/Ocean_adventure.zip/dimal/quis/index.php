<?php
include_once "../functions/functions.php";
if (!isset($_COOKIE["user_id"])) {
    header("Location: ../login.php");
}
$quizes = getQuizes($_GET["id"]);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz</title>
    <link rel="icon" href="favicon.png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
</head>

<body>
    <!-- start Quiz button -->
    <div class="start_btn"><button>Start Quiz</button></div>

    <!-- Info Box -->
    <div class="info_box">
        <div class="info-title"><span>Rules of this Quiz</span></div>
        <div class="info-list">
            <div class="info">1. You will have only <span>15 seconds</span> per each question.</div>
            <div class="info">2. Once you select your answer, it can't be undone.</div>
            <div class="info">3. You can't select any option once time goes off.</div>
            <div class="info">4. You can't exit from the Quiz while you're playing.</div>
            <div class="info">5. You'll get points on the basis of your correct answers.</div>
        </div>
        <div class="buttons">
            <button class="quit">Exit Quiz</button>
            <button class="restart">Continue</button>
        </div>
    </div>
    <div class="quiz_box">
        <header>
            <div class="title">Quiz Application</div>
            <div class="timer">
                <div class="time_left_txt">Time Left</div>
                <div class="timer_sec">15</div>
            </div>
            <div class="time_line"></div>
        </header>
        <section>
            <div class="que_text">
            </div>
            <div class="option_list">
            </div>
        </section>
        <footer>
            <div class="total_que">
            </div>
            <button class="next_btn">Next Question</button>
        </footer>
    </div>
    <div class="result_box">
        <div class="icon">
            <i class="fas fa-crown"></i>
        </div>
        <div class="complete_text">You've completed the Quiz!</div>
        <div class="score_text">
        </div>
        <div class="buttons">
            <button class="restart">Replay Quiz</button>
            <button class="quit" onclick="saveScore(<?=$_GET['id']?>)">Quit Quiz</button>
        </div>
    </div>
    <script>
        <?php

        ?>
        let questions = [
            <?php for ($i = 0; $i < 5; $i++) {
                echo "{";
                echo "numb:" . $i + 1 . ",";
                echo "question:'" . $quizes[$i]["quiz_question"] . "',";
                echo "answer:'" . $quizes[$i]["quiz_correct_answer"] . "',";
                echo "options:[";
                $answers = getAnswers($quizes[$i]["quiz_id"]);
                foreach ($answers as $answer) {
                    echo "'" . $answer["option_text"] . "',";
                }
                echo "]";
                echo "},";
            } ?>
        ];
    </script>
    <script src="script.js"></script>

</body>

</html>