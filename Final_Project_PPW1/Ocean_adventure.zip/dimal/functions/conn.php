<?php
$mysql = mysqli_connect("localhost","root","","ocean_adventure",3306);