<?php 
include_once "../functions/functions.php";
$depths = getDepths();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OceanLayers</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.4.0/p5.js"></script>
    <script src="script.js"></script>    
</head>
<body>
    <div class="final-video-container">
        <video id="final-video" src="src/animation/videofinal.mp4"></video>
    </div>
    <nav>
        <a href="#" id="logo-nav" class="logo-nav type02">
            <img src="src/imgs/logonav.png" alt="">
        </a>
        <div class="atm">
            <p class="text-white type01">
                <span id="atm">0000</span>
                ATM
            </p>
            
            
        </div>
        <button id="sound-control">
            <img class="sound-gif"  id="sound-gif" src="src/animation/sound-wave.gif" alt="">
        </button>
        <button id="burger">
            <img src="src/imgs/burgerMenu2.svg" alt="">
        </button>
    </nav>
    
    <div class="barometer">
        <div class="indicator"></div>
    </div>
    <div class="supra-container">
        <div class="main-container text-white">
            
            <!-- SURFACE -->
            
            <div class="container-zone0 surface">
                <button id="dive">
                    <h1 class="type02">DIVE</h1>
                </button>
                <img class="header-title" src="src/imgs/logonav.png" alt="">
                
                <audio id="background-audio" loop src="src/sound/ambient.mp3"></audio>
                
                <p class="header-body text-white type01 type-size01">The ocean cover 70% of Earth's surface. Yet 95% of it remains unknown. Dive in and explore the deepest parts of the ocean divided in it's <b>5 zones.</b></p>
                <div class="wave-container">
                    <div class="wave"></div>
                    <div class="wave"></div>
                </div>
            </div>

            <!-- EPIPELAGICO -->
            <div class="container-zone01 epipelagic ">
                <article class="zone-info">
                    <h1 class="zone-title type-size04 type02" ><?=$depths[0]["depth_zone_name"]?></h1>
                    <p class="text-white type01 type-size03"><?=$depths[0]["min_depth"]?> - <?=$depths[0]["max_depth"]?> meters from sea level</p>
                        <p class="info-bodytext type01 type-size03 text-white"><?=$depths[0]["depth_zone_description"]?></p>
                        <a href="../quis/?id=1">
                            <button class="video-button">
                        <h1 class="type02 type-size04 text-white">Play</h1>
                    </button>
                        </a>
                </article>
                <?php $animalAt = getAnimalAt(0);?>
                <article class="zone-subinfo margin-bottom50">
                    <h1 class="article-title type-size04 type03"><?=$animalAt["biota_name"]?></h1>
                    <img class="article-img" src="../assets/<?=$animalAt["image_path"]?>" alt="">
                    <p class="info-bodytext type01 type-size03 text-white"><?=$animalAt["biota_description"]?></p>
                </article>

            </div>
            <!-- MESOPELAGICO -->
            
            <div class="container-zone01 mesopelagic ">
                <article class="zone-info">
                    <h1 class="zone-title type-size04 type02" ><?=$depths[1]["depth_zone_name"]?></h1>
                    <p class="text-white type01 type-size03"><?=$depths[1]["min_depth"]?> - <?=$depths[1]["max_depth"]?> meters from sea level</p>
                        <p class="info-bodytext type01 type-size03 text-white"><?=$depths[1]["depth_zone_description"]?></p>
                        <a href="../quis/?id=2">
                            <button class="video-button">
                        <h1 class="type02 type-size04 text-white">Play</h1>
                    </button>
                        </a>
                </article>
                <?php $animalAt = getAnimalAt(1);?>
                <article class="zone-subinfo margin-bottom50">
                    <h1 class="article-title type-size04 type03"><?=$animalAt["biota_name"]?></h1>
                    <img class="article-img" src="../assets/<?=$animalAt["image_path"]?>" alt="">
                    <p class="info-bodytext type01 type-size03 text-white"><?=$animalAt["biota_description"]?></p>
                </article>

            </div>
            <!-- BATHYPELAGICO -->
            
            <div class="container-zone01 bathypelagic ">
                <article class="zone-info">
                    <h1 class="zone-title type-size04 type02" ><?=$depths[2]["depth_zone_name"]?></h1>
                    <p class="text-white type01 type-size03"><?=$depths[2]["min_depth"]?> - <?=$depths[2]["max_depth"]?> meters from sea level</p>
                        <p class="info-bodytext type01 type-size03 text-white"><?=$depths[2]["depth_zone_description"]?></p>
                        <a href="../quis/?id=3">
                            <button class="video-button">
                        <h1 class="type02 type-size04 text-white">Play</h1>
                    </button>
                        </a>
                </article>
                <?php $animalAt = getAnimalAt(2);?>
                <article class="zone-subinfo margin-bottom50">
                    <h1 class="article-title type-size04 type03"><?=$animalAt["biota_name"]?></h1>
                    <img class="article-img" src="../assets/<?=$animalAt["image_path"]?>" alt="">
                    <p class="info-bodytext type01 type-size03 text-white"><?=$animalAt["biota_description"]?></p>
                </article>

            </div>
            
            <!-- ABISSOPELAGICO -->
            <div class="container-zone01 abissopelagic ">
                <article class="zone-info">
                    <h1 class="zone-title type-size04 type02" ><?=$depths[3]["depth_zone_name"]?></h1>
                    <p class="text-white type01 type-size03"><?=$depths[3]["min_depth"]?> - <?=$depths[3]["max_depth"]?> meters from sea level</p>
                        <p class="info-bodytext type01 type-size03 text-white"><?=$depths[3]["depth_zone_description"]?></p>
                        <a href="../quis/?id=4">
                            <button class="video-button">
                        <h1 class="type02 type-size04 text-white">Play</h1>
                    </button>
                        </a>
                </article>
                <?php $animalAt = getAnimalAt(3);?>
                <article class="zone-subinfo margin-bottom50">
                    <h1 class="article-title type-size04 type03"><?=$animalAt["biota_name"]?></h1>
                    <img class="article-img" src="../assets/<?=$animalAt["image_path"]?>" alt="">
                    <p class="info-bodytext type01 type-size03 text-white"><?=$animalAt["biota_description"]?></p>
                </article>

            </div>
            <!-- HADOPELAGICO -->
            
            <div class="container-zone01 hadopelagic ">
                <article class="zone-info">
                    <h1 class="zone-title type-size04 type02" ><?=$depths[4]["depth_zone_name"]?></h1>
                    <p class="text-white type01 type-size03"><?=$depths[4]["min_depth"]?> - <?=$depths[4]["max_depth"]?> meters from sea level</p>
                        <p class="info-bodytext type01 type-size03 text-white"><?=$depths[4]["depth_zone_description"]?></p>
                        <a href="../quis/?id=5">
                            <button class="video-button">
                        <h1 class="type02 type-size04 text-white">Play</h1>
                    </button>
                        </a>
                </article>
                <?php $animalAt = getAnimalAt(4);?>
                <article class="zone-subinfo margin-bottom50">
                    <h1 class="article-title type-size04 type03"><?=$animalAt["biota_name"]?></h1>
                    <img class="article-img" src="../assets/<?=$animalAt["image_path"]?>" alt="">
                    <p class="info-bodytext type01 type-size03 text-white"><?=$animalAt["biota_description"]?></p>
                </article>

            </div>
            <!-- CHALLENGER DEEP -->
            <div class="container-zone01 challenger border-top">
                <h1 class="zone-title type-size04">Challenger deep</h1>
                <p class="text-white type01 type-size03">10935 meters from sea level</p>
                <a href="../">
                    <button class="video-button">
                        <h1 class="type02 type-size04 text-white">Home</h1>
                    </button>

                </a>
<!-- 
                <article class="info01">
                    <video controls src="src/animation/WhatsApp Video 2024-06-16 at 15.30.10.mp4"></video>
                    
                </article> -->
            </div>

            <footer>

            </footer>
        </div>
    </div>
</body>

</html>